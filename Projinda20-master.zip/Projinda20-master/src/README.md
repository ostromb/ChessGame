All the code for the chess game is put here.
